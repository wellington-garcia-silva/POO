import java.util.Random;
public class Questao{
    private String enunciado;
    private int gabarito;
    private static int idQuestao = 0;//

    public  Questao(){
        idQuestao++;
        Random r = new Random();
        int num1 = r.nextInt(10);
        int num2 = r.nextInt(10);
        System.out.printf("Questão" + idQuestao + " - ");
        enunciado = "Quanto é " + num1 + " * " + num2 + " ?";
        gabarito = num1*num2;
    }

    public int getIdQuestao(){
        return idQuestao;
    }

    public String getEnunciado(){
        return enunciado;
    }
    public boolean acertou(int resposta){
        return gabarito == resposta;
    }
}