import java.util.Scanner;
public class Prova{
    private Questao q;
    private Questao [] questao = new Questao [5];

    public Prova(){
        for(int i=0;i<5;i++){
            questao[i] = new Questao();
        }
        //q = new Questao();
    }

    public void aplicar(){
        int n = 0;
        int cont = 0;
        Scanner ent = new Scanner(System.in);
        while(n<5){
            
            //System.out.println("Responda a questao" + q.getEnunciado());
            System.out.println("Responda a questao" + questao[n].getEnunciado());
            int resp = ent.nextInt();
            
            if(q.acertou(resp)){
                System.out.println("Acertou");
                cont++;
            }
            else{
                System.out.println("Errou");
                cont++;
            }
            
            while(q.acertou(resp) == false){
                System.out.println("Você tem mais uma chance!");
                resp = ent.nextInt();
                cont++;
            }
            System.out.printf("Você tentou %d vez(es) e acertou a questão!",cont);
            n++;
            ent.close();
        }
       
    }

}